DEVICENAME = {
    'AUTO': 0,
    'USB': 1,
    'PARALLEL': 2,
    'SERIAL': 3
} 